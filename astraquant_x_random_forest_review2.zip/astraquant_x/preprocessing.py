import numpy as np
import pandas as pd


def clean_data(raw: pd.DataFrame) -> pd.DataFrame:
    data = raw.copy()
    data['Date'] = pd.to_datetime(data['Date'], utc=True).dt.tz_localize(None)
    for name in ['Open', 'High', 'Low', 'Close', 'Volume']:
        data[name] = pd.to_numeric(data[name], errors='coerce')
    data = data.replace([np.inf, -np.inf], np.nan)
    data = data.dropna(subset=['Date', 'Open', 'High', 'Low', 'Close', 'Volume'])
    data = data.drop_duplicates(subset=['Date'], keep='last').sort_values('Date').reset_index(drop=True)
    data = data[(data[['Open', 'High', 'Low', 'Close']] > 0).all(axis=1) & (data['Volume'] >= 0)]
    if len(data) < 150:
        raise ValueError('At least 150 valid trading days are required; select a longer date range.')
    return data.reset_index(drop=True)
