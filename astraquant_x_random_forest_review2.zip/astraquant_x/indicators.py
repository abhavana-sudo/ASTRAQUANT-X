import numpy as np
import pandas as pd

FEATURES = ['RSI', 'MACD', 'MACD_Signal', 'SMA20_Ratio', 'SMA50_Ratio', 'Log_Volume', 'Daily_Return']


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    data = df.copy()
    close = data['Close']
    data['SMA20'] = close.rolling(20, min_periods=20).mean()
    data['SMA50'] = close.rolling(50, min_periods=50).mean()
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    data['MACD'] = ema12 - ema26
    data['MACD_Signal'] = data['MACD'].ewm(span=9, adjust=False).mean()
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    avg_loss = loss.ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    data['RSI'] = (100 - 100/(1 + rs)).where(avg_loss != 0, 100).where(avg_gain != 0, 0)
    data['RSI'] = data['RSI'].where((avg_gain != 0) | (avg_loss != 0), 50)
    data['Daily_Return'] = close.pct_change()
    # Price-relative averages and log volume reduce scale differences across stocks.
    data['SMA20_Ratio'] = close / data['SMA20'] - 1
    data['SMA50_Ratio'] = close / data['SMA50'] - 1
    data['Log_Volume'] = np.log1p(data['Volume'])
    data['Bullish_Crossover'] = (data['SMA20'] > data['SMA50']) & (data['SMA20'].shift(1) <= data['SMA50'].shift(1))
    data['Bearish_Crossover'] = (data['SMA20'] < data['SMA50']) & (data['SMA20'].shift(1) >= data['SMA50'].shift(1))
    return data.replace([np.inf, -np.inf], np.nan)
