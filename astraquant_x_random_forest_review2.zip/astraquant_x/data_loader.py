import pandas as pd
import yfinance as yf


def load_data(ticker: str, start, end) -> pd.DataFrame:
    ticker = ticker.strip().upper()
    if not ticker or not all(c.isalnum() or c in '.-^=' for c in ticker):
        raise ValueError('Enter a valid ticker symbol (for example AAPL or MSFT).')
    try:
        data = yf.download(ticker, start=str(start), end=str(end), auto_adjust=True, progress=False, threads=False)
    except Exception as exc:
        raise RuntimeError(f'Unable to download data. Check internet access and ticker: {exc}') from exc
    if data is None or data.empty:
        raise ValueError('No market data returned. Check the ticker and date range.')
    if isinstance(data.columns, pd.MultiIndex):
        data.columns = data.columns.get_level_values(0)
    data = data.reset_index()
    if 'Datetime' in data.columns:
        data = data.rename(columns={'Datetime': 'Date'})
    columns = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume']
    missing = set(columns) - set(data.columns)
    if missing:
        raise ValueError(f'Data is missing columns: {sorted(missing)}')
    return data[columns].copy()
