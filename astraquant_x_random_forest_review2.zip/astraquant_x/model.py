import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.model_selection import TimeSeriesSplit
from sklearn.pipeline import Pipeline
from indicators import FEATURES


def build_pipeline(n_estimators=150, max_depth=6, min_samples_leaf=5):
    return Pipeline([('classifier', RandomForestClassifier(
        n_estimators=n_estimators, max_depth=max_depth,
        min_samples_leaf=min_samples_leaf, random_state=42, n_jobs=-1,
        class_weight='balanced_subsample'))])


def train_and_predict(labeled: pd.DataFrame):
    data = labeled.dropna(subset=FEATURES + ['Target']).reset_index(drop=True)
    if len(data) < 100:
        raise ValueError('Insufficient feature rows after preprocessing.')
    split = int(len(data) * 0.8)
    # Purge the training observation whose next-day label uses the first test price.
    train = data.iloc[:split - 1].copy()
    test = data.iloc[split:].copy()
    if len(train) < 60 or len(test) < 20:
        raise ValueError('Not enough observations for chronological training/testing.')
    x_train, y_train = train[FEATURES], train['Target']
    x_test, y_test = test[FEATURES], test['Target']
    if y_train.nunique() < 2:
        raise ValueError('Training data contains fewer than two signal classes. Try a different threshold or range.')
    best_params, best_score = {'n_estimators': 150, 'max_depth': 6, 'min_samples_leaf': 5}, -np.inf
    for depth, leaf in [(4, 5), (6, 5), (8, 10)]:
        scores = []
        for a, b in TimeSeriesSplit(n_splits=3, gap=1).split(x_train):
            if y_train.iloc[a].nunique() < 2:
                continue
            candidate = build_pipeline(150, depth, leaf)
            candidate.fit(x_train.iloc[a], y_train.iloc[a])
            pred = candidate.predict(x_train.iloc[b])
            scores.append(f1_score(y_train.iloc[b], pred, average='macro', zero_division=0))
        if scores and np.mean(scores) > best_score:
            best_params = {'n_estimators': 150, 'max_depth': depth, 'min_samples_leaf': leaf}
            best_score = float(np.mean(scores))
    model = build_pipeline(**best_params)
    model.fit(x_train, y_train)
    baseline = DummyClassifier(strategy='most_frequent')
    baseline.fit(x_train, y_train)
    predicted = model.predict(x_test)
    probabilities = model.predict_proba(x_test)
    output = test[['Date', 'Close', 'Target']].copy()
    output['Predicted'] = predicted
    for i, name in enumerate(model.classes_):
        output[f'P_{name}'] = probabilities[:, i]
    output['Confidence'] = probabilities.max(axis=1)
    return {'model': model, 'baseline': baseline, 'train': train, 'test': test,
            'predictions': output, 'best_params': best_params, 'cv_f1': best_score,
            'x_test': x_test, 'y_test': y_test}


def explain_prediction(model, features: pd.Series):
    # Global impurity-based feature importance; not a per-prediction explanation.
    x = pd.DataFrame([features[FEATURES]])
    predicted = model.predict(x)[0]
    importance = model.named_steps['classifier'].feature_importances_
    ranking = sorted(zip(FEATURES, importance), key=lambda v: v[1], reverse=True)
    return predicted, ranking[:3]
