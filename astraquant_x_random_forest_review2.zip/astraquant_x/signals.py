import numpy as np
import pandas as pd

CLASSES = ['SELL', 'HOLD', 'BUY']


def create_labels(data: pd.DataFrame, threshold: float = 0.005) -> pd.DataFrame:
    if not 0 < threshold < 0.2:
        raise ValueError('Threshold must be between 0 and 0.2 (exclusive).')
    result = data.copy()
    result['Future_Return'] = result['Close'].shift(-1) / result['Close'] - 1
    result['Target'] = np.select(
        [result['Future_Return'] < -threshold, result['Future_Return'] > threshold],
        ['SELL', 'BUY'], default='HOLD'
    )
    # Last row has no observed next-day return; never treat it as a known HOLD label.
    result.loc[result['Future_Return'].isna(), 'Target'] = None
    return result
