from datetime import date, timedelta
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import streamlit as st
from data_loader import load_data
from preprocessing import clean_data
from indicators import add_indicators, FEATURES
from signals import create_labels
from model import train_and_predict, explain_prediction
from evaluation import evaluate

st.set_page_config(page_title='ASTRAQUANT X', page_icon='📈', layout='wide')
st.markdown('''<style>.stApp {background-color:#0c1220;color:#e9eef9} div[data-testid="stMetric"] {background:#182238;padding:16px;border-radius:12px}</style>''', unsafe_allow_html=True)
st.title('📈 ASTRAQUANT X')
st.caption('Educational machine-learning trading signal research | No live trades or profitability claims')

with st.sidebar:
    st.header('Market settings')
    ticker = st.text_input('Stock ticker', 'AAPL').strip().upper()
    start = st.date_input('Start date', date.today() - timedelta(days=365 * 5))
    end = st.date_input('End date (exclusive)', date.today())
    threshold_pct = st.slider('Next-day movement threshold (%)', 0.1, 3.0, 0.5, 0.1)
    run = st.button('Load data & train model', type='primary')

if run:
    try:
        if start >= end:
            raise ValueError('Start date must be earlier than end date.')
        with st.spinner('Downloading data, computing indicators, training model...'):
            raw = load_data(ticker, start, end)
            cleaned = clean_data(raw)
            featured = add_indicators(cleaned)
            labeled = create_labels(featured, threshold_pct / 100)
            results = train_and_predict(labeled)
            metrics, confusion, report = evaluate(results)
            # Use a separate latest observation for the current prediction;
            # its future return is unknown and it is not in training/testing.
            latest = featured.dropna(subset=FEATURES).iloc[-1]
            model = results['model']
            latest_x = pd.DataFrame([latest[FEATURES]])
            latest_prediction = model.predict(latest_x)[0]
            latest_probs = dict(zip(model.classes_, model.predict_proba(latest_x)[0]))
            _, contributions = explain_prediction(model, latest)
            st.session_state['analysis'] = (raw, cleaned, featured, results, metrics, confusion, report,
                                            latest, latest_prediction, latest_probs, contributions, ticker)
    except Exception as exc:
        st.error(f'Unable to complete analysis: {exc}')

if 'analysis' not in st.session_state:
    st.info('Select a ticker and click **Load data & train model** to begin.')
    st.stop()

(raw, cleaned, featured, results, metrics, confusion, report, latest,
 latest_prediction, latest_probs, contributions, analyzed_ticker) = st.session_state['analysis']
st.caption(f'Analysis loaded for {analyzed_ticker}. To apply new settings, click Load data & train model again.')

st.header('1 · Market overview')
a,b,c = st.columns(3)
a.metric('Latest historical close', f"${latest['Close']:,.2f}")
b.metric('Change over selected range', f"{(cleaned['Close'].iloc[-1]/cleaned['Close'].iloc[0]-1)*100:.2f}%")
c.metric('Latest historical volume', f"{int(latest['Volume']):,}")
price_fig = go.Figure()
price_fig.add_trace(go.Scatter(x=featured['Date'], y=featured['Close'], name='Close'))
price_fig.add_trace(go.Scatter(x=featured['Date'], y=featured['SMA20'], name='SMA20'))
price_fig.add_trace(go.Scatter(x=featured['Date'], y=featured['SMA50'], name='SMA50'))
price_fig.update_layout(template='plotly_dark', title='Historical closing price and moving averages', xaxis_title='Date', yaxis_title='Price')
st.plotly_chart(price_fig, use_container_width=True)

with st.expander('Original vs cleaned dataset'):
    st.write('Original data', raw.shape, 'Cleaned data', cleaned.shape)
    st.dataframe(raw.head(15), use_container_width=True)
    st.dataframe(cleaned.head(15), use_container_width=True)
    st.download_button('Download cleaned CSV', cleaned.to_csv(index=False), file_name=f'{analyzed_ticker}_cleaned.csv', mime='text/csv')

st.header('2 · Technical indicators')
left,right = st.columns(2)
with left:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=featured['Date'], y=featured['RSI'], name='RSI'))
    fig.add_hline(y=70, line_dash='dash', line_color='red')
    fig.add_hline(y=30, line_dash='dash', line_color='green')
    fig.update_layout(template='plotly_dark', title='RSI (14)', yaxis_title='RSI')
    st.plotly_chart(fig, use_container_width=True)
with right:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=featured['Date'], y=featured['MACD'], name='MACD'))
    fig.add_trace(go.Scatter(x=featured['Date'], y=featured['MACD_Signal'], name='Signal line'))
    fig.update_layout(template='plotly_dark', title='MACD (12, 26, 9)')
    st.plotly_chart(fig, use_container_width=True)
st.dataframe(featured[['Date','Close','RSI','MACD','MACD_Signal','SMA20','SMA50','Bullish_Crossover','Bearish_Crossover']].tail(15), use_container_width=True)

st.header('3 · AI prediction')
st.subheader(f'Latest available day: {latest_prediction}')
st.caption(f"Prediction as of {latest['Date'].date()}, for the next trading day's close-to-close movement. This forecast uses the model trained on the earlier training period; it is not a validated live trading signal.")
cols = st.columns(len(latest_probs))
for col, (name, prob) in zip(cols, latest_probs.items()):
    col.metric(f'P({name})', f'{prob:.1%}')
st.write('Most important features overall in the trained Random Forest (global importance, not a reason for this individual prediction):')
for name, contribution in contributions:
    st.write(f'- {name}: {contribution:+.3f}')

st.header('4 · Training and testing')
st.write(f"Chronological split: {len(results['train'])} training observations, {len(results['test'])} test observations; one boundary row purged. Best Random Forest settings = {results['best_params']}.")
cols = st.columns(4)
for col, name in zip(cols, ['Accuracy','Precision (macro)','Recall (macro)','F1 (macro)']):
    col.metric(name, f'{metrics[name]:.1%}')
st.write(f"Majority-class baseline accuracy: {metrics['Baseline accuracy']:.1%}; baseline macro-F1: {metrics['Baseline F1 (macro)']:.1%}.")
left,right = st.columns(2)
with left:
    fig = px.imshow(confusion, text_auto=True, color_continuous_scale='Blues', title='Confusion matrix (rows=actual, columns=predicted)')
    fig.update_layout(template='plotly_dark')
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader('Classification report')
    st.dataframe(report, use_container_width=True)

st.header('5 · Buy/Sell/Hold signals on unseen test dates')
predictions = results['predictions']
fig = go.Figure()
fig.add_trace(go.Scatter(x=predictions['Date'], y=predictions['Close'], name='Close', mode='lines'))
for name, symbol, color in [('BUY','triangle-up','#20c997'),('SELL','triangle-down','#ff6b6b'),('HOLD','circle','#a9b4c7')]:
    selected = predictions[predictions['Predicted'] == name]
    fig.add_trace(go.Scatter(x=selected['Date'], y=selected['Close'], name=f'Predicted {name}', mode='markers', marker=dict(symbol=symbol, color=color, size=9)))
fig.update_layout(template='plotly_dark', title='Out-of-sample predicted signals (not executed trades)', xaxis_title='Date', yaxis_title='Price')
st.plotly_chart(fig, use_container_width=True)
st.dataframe(predictions.tail(30), use_container_width=True)
st.download_button('Download test predictions CSV', predictions.to_csv(index=False), file_name=f'{analyzed_ticker}_test_predictions.csv', mime='text/csv')
st.caption('For research/education only. Next-day labels are historical outcomes; real trading involves transaction costs, slippage, risk, and possible losses.')
