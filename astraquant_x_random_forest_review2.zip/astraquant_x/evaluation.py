import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score, precision_score, recall_score
from signals import CLASSES


def evaluate(results):
    actual = results['y_test']
    predicted = results['predictions']['Predicted']
    baseline = results['baseline'].predict(results['x_test'])
    metrics = {
        'Accuracy': accuracy_score(actual, predicted),
        'Precision (macro)': precision_score(actual, predicted, average='macro', zero_division=0),
        'Recall (macro)': recall_score(actual, predicted, average='macro', zero_division=0),
        'F1 (macro)': f1_score(actual, predicted, average='macro', zero_division=0),
        'Baseline accuracy': accuracy_score(actual, baseline),
        'Baseline F1 (macro)': f1_score(actual, baseline, average='macro', zero_division=0),
    }
    confusion = pd.DataFrame(confusion_matrix(actual, predicted, labels=CLASSES), index=CLASSES, columns=CLASSES)
    report = pd.DataFrame(classification_report(actual, predicted, labels=CLASSES, output_dict=True, zero_division=0)).T
    return metrics, confusion, report
