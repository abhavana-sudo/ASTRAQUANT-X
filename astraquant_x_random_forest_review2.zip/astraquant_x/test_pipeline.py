"""Offline software smoke test; synthetic prices are NOT real trading evidence."""
import numpy as np
import pandas as pd
from preprocessing import clean_data
from indicators import add_indicators, FEATURES
from signals import create_labels
from model import train_and_predict
from evaluation import evaluate

rng = np.random.default_rng(42)
n = 750
close = 100 * np.exp(np.cumsum(rng.normal(0.0001, 0.018, n)))
raw = pd.DataFrame({'Date': pd.bdate_range('2022-01-03', periods=n), 'Open': close * 0.998,
                    'High': close * 1.012, 'Low': close * 0.988, 'Close': close,
                    'Volume': rng.integers(100000, 2000000, n)})
cleaned = clean_data(raw)
featured = add_indicators(cleaned)
labeled = create_labels(featured, threshold=0.005)
result = train_and_predict(labeled)
metrics, confusion, report = evaluate(result)
assert len(result['predictions']) > 20
assert set(result['predictions']['Predicted']).issubset({'BUY', 'SELL', 'HOLD'})
assert result['train']['Date'].max() < result['test']['Date'].min()
assert all(0 <= v <= 1 for v in metrics.values())
print('PASS: preprocessing, indicators, training, testing, signals, evaluation')
print('Synthetic-data metrics (NOT real-world performance):', metrics)
