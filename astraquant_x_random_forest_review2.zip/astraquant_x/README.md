# ASTRAQUANT X — Review 2

Educational, next-day BUY / SELL / HOLD prediction using historical OHLCV, RSI, MACD, moving averages, and Random Forest classification (scikit-learn).

## Run in VS Code

1. Install Python 3.10 or newer and open this project folder in VS Code.
2. In the VS Code terminal, create a virtual environment:
   - Windows: `py -m venv .venv` then `.venv\Scripts\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
3. Install dependencies: `python -m pip install -r requirements.txt`
4. Run: `python -m streamlit run app.py`
5. Open the local browser URL Streamlit prints. Enter `AAPL`, choose ~5 years of dates, and click **Load data & train model**.

Internet is needed for Yahoo Finance data downloads. If the ticker is invalid or the network is unavailable, the dashboard displays an error rather than fabricating prices. Yahoo's data is typically daily, not true high-frequency/order-book data.

## Files

- `app.py`: Streamlit dashboard and graphs
- `data_loader.py`: fetches historical OHLCV from yfinance
- `preprocessing.py`: cleans missing/duplicate/invalid data
- `indicators.py`: RSI, MACD, SMA20, SMA50 and derived features
- `signals.py`: next-day return labels
- `model.py`: leakage-aware chronological train/test and Random Forest classification
- `evaluation.py`: accuracy, precision, recall, F1, confusion matrix, baseline
- `test_pipeline.py`: offline synthetic-data unit smoke test (NOT evidence of market accuracy)

## Model and mathematical explanation

Given closing price P_t:

- Simple Moving Average: `SMA_n(t) = (P_t + ... + P_(t-n+1)) / n`.
- Exponential Moving Average: `EMA_t = alpha*P_t + (1-alpha)*EMA_(t-1)`, with `alpha=2/(n+1)`.
- RSI(14): `RSI = 100 - 100/(1+RS)`; `RS = smoothed average gain / smoothed average loss`. Wilder-style exponential smoothing uses alpha=1/14.
- MACD: `EMA_12 - EMA_26`; signal line: `EMA_9(MACD)`.
- Daily return: `r_t = P_t/P_(t-1) - 1`.
- Next-day target: `r_(t+1) = P_(t+1)/P_t - 1`.
- If next-day return is above threshold: BUY; below negative threshold: SELL; otherwise HOLD.
- Random Forest class probability: `P(class=k | x) = (1/T) * sum_t P_t(class=k | x)` where T is the number of decision trees; each tree estimates probabilities from class proportions in a leaf.

Features are RSI, MACD, MACD signal, close/SMA20 - 1, close/SMA50 - 1, log(1+volume), and current daily return. SMA ratios are scale-normalized versions of the requested SMA features; raw SMAs are displayed on the dashboard. All features are calculated from prices through time t only.

Pipeline: **Historical OHLCV -> Cleaning -> Technical Indicators -> Chronological Train/Test -> Random Forest -> Predicted BUY/SELL/HOLD -> Charts and Metrics**.

The model uses the earliest ~80% for training, skips one boundary observation whose label would depend on the first test day's price, and evaluates on the latest ~20%. A `TimeSeriesSplit(gap=1)` tunes tree depth and minimum leaf size on the training segment only. It compares against a majority-class baseline. Metrics are calculated only after actual data is downloaded; no claimed performance is included in this project.

## Demo and test plan

1. Run `python test_pipeline.py` to test the processing and training workflow on synthetic prices; these are **software checks**, not financial performance results.
2. Launch Streamlit and download real historical data using `AAPL` or `MSFT`.
3. Show original/cleaned rows, RSI, MACD, and moving averages.
4. Show latest prediction probabilities and global feature importance.
5. Show chronological train/test counts, genuine metrics, confusion matrix, baseline, and predicted signals.
6. Download cleaned data and test predictions using dashboard buttons.
7. Try an invalid ticker and a short date range to demonstrate graceful errors.

## Caveats

- This is a **daily close-to-close** research example, not an HFT execution system.
- The latest forecast uses the model fitted on the earlier 80% training period, without retraining on the held-out period. It is **not** an independently live-validated trading signal.
- If the latest model forecast is generated from a model trained on only the first 80% of the full history, it may not capture all recent patterns; retraining and walk-forward validation are future work.
- The dashboard does **not** execute trades, calculate net profit, or establish profitability. Transaction costs, slippage, position sizing, and risk are Review 3 work.
- Random Forest may predict mostly HOLD if the threshold is too high. Lowering the threshold changes the task definition and must not be selected based on test-set performance.
- Source data can be revised; results depend on ticker, period, and package versions.
